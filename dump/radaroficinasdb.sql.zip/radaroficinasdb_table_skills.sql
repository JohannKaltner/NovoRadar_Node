
-- --------------------------------------------------------

--
-- Estrutura da tabela `skills`
--

CREATE TABLE IF NOT EXISTS `skills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `skills`
--

INSERT INTO `skills` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Lanternagem', '2020-01-11 00:24:49', '2020-01-11 00:24:49'),
(2, 'Mecânica', '2020-01-11 00:24:59', '2020-01-11 00:24:59'),
(3, 'Elétrica', '2020-01-11 00:25:05', '2020-01-11 00:25:05'),
(4, 'Chapeação', '2020-01-11 00:24:59', '2020-01-11 00:24:59'),
(5, 'Pintura', '2020-01-11 00:24:59', '2020-01-11 00:24:59');
