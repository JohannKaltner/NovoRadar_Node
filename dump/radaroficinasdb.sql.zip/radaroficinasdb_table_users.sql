
-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `primeiro_nome` varchar(255) NOT NULL,
  `ultimo_nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `rua` varchar(255) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `bairro` varchar(255) DEFAULT NULL,
  `cidade` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `lat` float DEFAULT NULL,
  `long` float DEFAULT NULL,
  `nascimento` varchar(50) DEFAULT NULL,
  `genero` varchar(15) DEFAULT NULL,
  `criadoEm` varchar(50) NOT NULL,
  `atualizadoEm` varchar(50) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `facebook_id` varchar(255) DEFAULT NULL,
  `telefone` varchar(15) NOT NULL,
  `hasOficina` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `primeiro_nome`, `ultimo_nome`, `email`, `rua`, `numero`, `bairro`, `cidade`, `estado`, `lat`, `long`, `nascimento`, `genero`, `criadoEm`, `atualizadoEm`, `senha`, `facebook_id`, `telefone`, `hasOficina`) VALUES
(1, 'Johann', 'Kaltner DOliveira', 'johannkaltnerdev@radar.com.br', 'Rua Dw', 143, 'Recreio Dos Bandeirantes', 'Rio de Janeiro', 'Rio de Janeiro', -23.0286, -43.4745, '10/08/2000', 'Masculino', '10/08/2000', '10/08/2018', '$2b$10$LHiH6eI8wmRjDfT80blsI.VSipXZwcZA7F2WXMyxJD/PQI4J/./02', NULL, '21 982543102', 0);
