
-- --------------------------------------------------------

--
-- Estrutura da tabela `agendamento_historico`
--

CREATE TABLE IF NOT EXISTS `agendamento_historico` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_agendamento_historico` int(11) NOT NULL,
  `id_oficina` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `primeiro_nome_usuario` varchar(200) DEFAULT NULL,
  `rua_usuario` varchar(200) DEFAULT NULL,
  `bairro_usuario` varchar(200) DEFAULT NULL,
  `numero_usuario` varchar(200) DEFAULT NULL,
  `telefone_usuario` varchar(15) NOT NULL,
  `situacao` int(11) DEFAULT NULL,
  `criadoEm` varchar(20) DEFAULT NULL,
  `atualizadoEm` varchar(20) DEFAULT NULL,
  `obs` varchar(2000) DEFAULT NULL,
  `id_veiculo` int(11) DEFAULT NULL,
  `preco` varchar(50) DEFAULT NULL,
  `prazo` varchar(30) DEFAULT NULL,
  `modelo_veiculo` varchar(50) NOT NULL,
  `marca_veiculo` varchar(50) NOT NULL,
  `ano_veiculo` varchar(4) NOT NULL,
  `tipo_combustivel` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `agendamento_historico`
--

INSERT INTO `agendamento_historico` (`id`, `id_agendamento_historico`, `id_oficina`, `id_usuario`, `primeiro_nome_usuario`, `rua_usuario`, `bairro_usuario`, `numero_usuario`, `telefone_usuario`, `situacao`, `criadoEm`, `atualizadoEm`, `obs`, `id_veiculo`, `preco`, `prazo`, `modelo_veiculo`, `marca_veiculo`, `ano_veiculo`, `tipo_combustivel`) VALUES
(8, 4, 1, 1, 'Johann Kaltner D\'Oliveira', 'Rua Dw', 'Recreio dos Bandeirantes', '143', '21 98254-3102', 0, '21/12/2020', '21/12/2020', 'apto 202', 1, '10,00', '60', 'Argo', 'Fiat', '2020', 'Gasolina'),
(9, 4, 1, 1, 'Johann Kaltner D\'Oliveira', 'Rua Dw', 'Recreio dos Bandeirantes', '143', '21 98254-3102', 0, '21/12/2020', '21/12/2020', 'apto 202', 1, '10,00', '60', 'Argo', 'Fiat', '2020', 'Gasolina'),
(10, 4, 1, 1, 'Johann Kaltner D\'Oliveira', 'Rua Dw', 'Recreio dos Bandeirantes', '143', '21 98254-3102', 1, '21/12/2020', '21/12/2020', 'apto 202', 1, '10,00', '60', 'Argo', 'Fiat', '2020', 'Gasolina'),
(11, 4, 1, 1, 'Johann Kaltner D\'Oliveira', 'Rua Dw', 'Recreio dos Bandeirantes', '143', '21 98254-3102', 0, '21/12/2020', '21/12/2020', 'apto 202', 1, '10,00', '60', 'Argo', 'Fiat', '2020', 'Gasolina'),
(12, 4, 1, 1, 'Johann Kaltner D\'Oliveira', 'Rua Dw', 'Recreio dos Bandeirantes', '143', '21 98254-3102', 1, '21/12/2020', '21/12/2020', 'apto 202', 1, '10,00', '60', 'Argo', 'Fiat', '2020', 'Gasolina'),
(13, 4, 1, 1, 'Johann Kaltner D\'Oliveira', 'Rua Dw', 'Recreio dos Bandeirantes', '143', '21 98254-3102', 2, '21/12/2020', '21/12/2020', 'apto 202', 1, '10,00', '60', 'Argo', 'Fiat', '2020', 'Gasolina'),
(14, 1, 1, 1, 'Johann Kaltner D\'Oliveira', 'Rua Dw', 'Recreio dos Bandeirantes', '143', '21 98254-3102', 2, '21/12/2020', '21/12/2020', 'apto 202', 1, '10,00', '60', 'Uno', 'Fiat', '1997', 'Total Flex'),
(15, 1, 1, 1, 'Johann Kaltner D\'Oliveira', 'Rua Dw', 'Recreio dos Bandeirantes', '143', '21 98254-3102', 2, '21/12/2020', '21/12/2020', 'apto 202', 1, '10,00', '60', 'Uno', 'Fiat', '1997', 'Total Flex'),
(16, 1, 1, 1, 'Johann Kaltner D\'Oliveira', 'Rua Dw', 'Recreio dos Bandeirantes', '143', '21 98254-3102', 3, '21/12/2020', '21/12/2020', 'apto 202', 1, '10,00', '60', 'Uno', 'Fiat', '1997', 'Total Flex'),
(17, 1, 1, 1, 'Johann Kaltner D\'Oliveira', 'Rua Dw', 'Recreio dos Bandeirantes', '143', '21 98254-3102', 4, '21/12/2020', '21/12/2020', 'apto 202', 1, '10,00', '60', 'Uno', 'Fiat', '1997', 'Total Flex'),
(18, 1, 1, 1, 'Johann Kaltner D\'Oliveira', 'Rua Dw', 'Recreio dos Bandeirantes', '143', '21 98254-3102', 3, '21/12/2020', '21/12/2020', 'apto 202', 1, '10,00', '60', 'Uno', 'Fiat', '1997', 'Total Flex'),
(19, 1, 1, 1, 'Johann Kaltner D\'Oliveira', 'Rua Dw', 'Recreio dos Bandeirantes', '143', '21 98254-3102', 4, '21/12/2020', '21/12/2020', 'apto 202', 1, '10,00', '60', 'Uno', 'Fiat', '1997', 'Total Flex');
