
-- --------------------------------------------------------

--
-- Estrutura da tabela `oficinas`
--

CREATE TABLE IF NOT EXISTS `oficinas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `cnpj` varchar(255) DEFAULT NULL,
  `rua` varchar(255) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `bairro` varchar(255) DEFAULT NULL,
  `cidade` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `latitude` float DEFAULT NULL,
  `longitude` float DEFAULT NULL,
  `id_usuario` int(11) NOT NULL,
  `criadoEm` datetime NOT NULL,
  `atualizadoEm` datetime NOT NULL,
  `cep` int(11) DEFAULT NULL,
  `ddd` int(11) DEFAULT NULL,
  `telefone1` int(11) DEFAULT NULL,
  `telefone2` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `oficinas`
--

INSERT INTO `oficinas` (`id`, `nome`, `company`, `cnpj`, `rua`, `numero`, `bairro`, `cidade`, `estado`, `latitude`, `longitude`, `id_usuario`, `criadoEm`, `atualizadoEm`, `cep`, `ddd`, `telefone1`, `telefone2`) VALUES
(1, 'Auto-Peças do Johann', 'Auto-Peças do Johann', '6666666-66/666', 'Rua do Johann', 666, 'Recreio dos Bandeirantes', ' Rio de Janeiro', ' Rio de Janeiro', -23.0286, -43.4747, 2, '2020-12-22 13:22:50', '2020-12-22 13:22:50', 22795780, 111, 111, 111),
(2, 'Auto-Peças do Johann 2', 'Auto-Peças do Johann 2', '6666666-66/666', 'Rua do Johann 2', 666, 'Recreio dos Bandeirantes 2', ' Rio de Janeiro 2', ' Rio de Janeiro 2', -23.0286, -43.4747, 0, '2020-12-22 13:22:50', '2020-12-22 13:22:50', 22795780, 111, 111, 111),
(4, 'Auto-Peças do Johann 3  ', 'Auto-Peças do Johann 3', '6666666-66/666', 'Rua do Johann', 666, 'Recreio dos Bandeirantes', ' Rio de Janeiro', ' Rio de Janeiro', -23.0286, -43.4747, 2, '2020-12-22 13:22:50', '2020-12-22 13:22:50', 22795780, 111, 111, 111),
(5, 'Auto-Peças do Johann 4', 'Auto-Peças do Johann 4', '6666666-66/666', 'Rua do Johann 4', 666, 'Recreio dos Bandeirantes 4', ' Rio de Janeiro 4', ' Rio de Janeiro 4', -23.0286, -43.4747, 0, '2020-12-22 13:22:50', '2020-12-22 13:22:50', 22795780, 111, 111, 111),
(6, 'Auto-Peças do Johann 5', 'Auto-Peças do Johann 5', '6666666-66/666', 'Rua do Johann', 666, 'Recreio dos Bandeirantes', ' Rio de Janeiro', ' Rio de Janeiro', -23.0286, -43.4747, 2, '2020-12-22 13:22:50', '2020-12-22 13:22:50', 22795780, 111, 111, 111),
(7, 'Auto-Peças do Johann 6', 'Auto-Peças do Johann 6', '6666666-66/666', 'Rua do Johann 2', 666, 'Recreio dos Bandeirantes 6', ' Rio de Janeiro 6', ' Rio de Janeiro 2', -23.0286, -43.4747, 0, '2020-12-22 13:22:50', '2020-12-22 13:22:50', 22795780, 111, 111, 111),
(8, 'Auto-Peças do Johann 3  ', 'Auto-Peças do Johann 3', '6666666-66/666', 'Rua do Johann', 666, 'Recreio dos Bandeirantes', ' Rio de Janeiro', ' Rio de Janeiro', -23.0286, -43.4747, 2, '2020-12-22 13:22:50', '2020-12-22 13:22:50', 22795780, 111, 111, 111),
(9, 'Auto-Peças do Johann 4', 'Auto-Peças do Johann 4', '6666666-66/666', 'Rua do Johann 4', 666, 'Recreio dos Bandeirantes 4', ' Rio de Janeiro 4', ' Rio de Janeiro 4', -23.0286, -43.4747, 0, '2020-12-22 13:22:50', '2020-12-22 13:22:50', 22795780, 111, 111, 111),
(10, 'Auto-Peças do Johann 2', 'Auto-Peças do Johann 2', '6666666-66/666', 'Rua do Johann 2', 666, 'Recreio dos Bandeirantes 2', ' Rio de Janeiro 2', ' Rio de Janeiro 2', -23.0286, -43.4747, 0, '2020-12-22 13:22:50', '2020-12-22 13:22:50', 22795780, 111, 111, 111),
(11, 'Auto-Peças do Johann', 'Auto-Peças do Johann', '6666666-66/666', 'Rua do Johann', 666, 'Recreio dos Bandeirantes', ' Rio de Janeiro', ' Rio de Janeiro', -23.0286, -43.4747, 2, '2020-12-22 13:22:50', '2020-12-22 13:22:50', 22795780, 111, 111, 111),
(12, 'Auto-Peças do Johann', 'Auto-Peças do Johann', '6666666-66/666', 'Rua do Johann', 666, 'Recreio dos Bandeirantes', ' Rio de Janeiro', ' Rio de Janeiro', -23.0286, -43.4747, 2, '2020-12-22 13:22:50', '2020-12-22 13:22:50', 22795780, 111, 111, 111),
(13, 'Auto-Peças do Johann', 'Auto-Peças do Johann', '6666666-66/666', 'Rua do Johann', 666, 'Recreio dos Bandeirantes', ' Rio de Janeiro', ' Rio de Janeiro', -23.0286, -43.4747, 2, '2020-12-22 13:22:50', '2020-12-22 13:22:50', 22795780, 111, 111, 111);
